"use client";

import { User, Phone, Mail, Users, ArrowRight } from "lucide-react";
import Background from "@/components/Background";
import AuthCard from "@/components/AuthCard";
import Logo from "@/components/Logo";

export default function EmergencyPage() {
  const contacts = [1, 2, 3];

  return (
    <Background>
      <AuthCard>

        <Logo />

        <h2 className="text-center text-2xl font-bold">
          Emergency Contacts
        </h2>

        <p className="mt-2 mb-8 text-center text-slate-400">
          Add three trusted contacts who will receive
          emergency alerts and your live location.
        </p>

        {contacts.map((contact) => (
          <div
            key={contact}
            className="mb-6 rounded-2xl border border-slate-700 bg-slate-900/40 p-5"
          >
            <h3 className="mb-5 text-lg font-semibold text-cyan-400">
              Contact {contact}
            </h3>

            {/* Name */}

            <div className="relative mb-4">

              <User
                className="absolute left-4 top-4 text-cyan-400"
                size={20}
              />

              <input
                type="text"
                placeholder="Full Name"
                className="h-14 w-full rounded-xl border border-slate-700 bg-slate-900 pl-12 text-white outline-none focus:border-cyan-500"
              />

            </div>

            {/* Relation */}

            <div className="relative mb-4">

              <Users
                className="absolute left-4 top-4 text-cyan-400"
                size={20}
              />

              <input
                type="text"
                placeholder="Relation (Father, Friend...)"
                className="h-14 w-full rounded-xl border border-slate-700 bg-slate-900 pl-12 text-white outline-none focus:border-cyan-500"
              />

            </div>

            {/* Phone */}

            <div className="relative mb-4">

              <Phone
                className="absolute left-4 top-4 text-cyan-400"
                size={20}
              />

              <input
                type="tel"
                placeholder="Phone Number"
                className="h-14 w-full rounded-xl border border-slate-700 bg-slate-900 pl-12 text-white outline-none focus:border-cyan-500"
              />

            </div>

            {/* Email */}

            <div className="relative">

              <Mail
                className="absolute left-4 top-4 text-cyan-400"
                size={20}
              />

              <input
                type="email"
                placeholder="Email Address"
                className="h-14 w-full rounded-xl border border-slate-700 bg-slate-900 pl-12 text-white outline-none focus:border-cyan-500"
              />

            </div>

          </div>
        ))}

        <button
          className="mt-4 flex h-14 w-full items-center justify-center gap-2 rounded-xl bg-cyan-500 text-lg font-semibold transition hover:bg-cyan-600"
        >
          Continue

          <ArrowRight size={20} />
        </button>

      </AuthCard>
    </Background>
  );
}