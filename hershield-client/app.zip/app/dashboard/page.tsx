"use client";

import { useRouter } from "next/navigation";
import {
  Shield,
  MapPinned,
  User,
  Phone,
  LogOut,
  ArrowRight,
} from "lucide-react";

export default function DashboardPage() {
  const router = useRouter();

  return (
    <main className="min-h-screen bg-[#07111F] text-white">

      <div className="mx-auto max-w-6xl px-6 py-10">

        <h1 className="text-4xl font-bold">
          Welcome 👋
        </h1>

        <p className="mt-2 text-slate-400">
          Your AI Powered Women Safety Assistant
        </p>

        <div className="mt-10 grid gap-6 md:grid-cols-2">

          {/* Safe Journey */}

          <div
            onClick={() => router.push("/journey")}
            className="cursor-pointer rounded-3xl border border-cyan-500/20 bg-slate-900 p-8 transition hover:scale-[1.02]"
          >
            <MapPinned
              size={45}
              className="text-cyan-400"
            />

            <h2 className="mt-6 text-2xl font-bold">
              Start Safe Journey
            </h2>

            <p className="mt-2 text-slate-400">
              Find the safest AI recommended route.
            </p>

            <div className="mt-6 flex items-center text-cyan-400">
              Start
              <ArrowRight className="ml-2" size={18} />
            </div>
          </div>

          {/* AI Monitoring */}

          <div className="rounded-3xl border border-green-500/20 bg-slate-900 p-8">

            <Shield
              size={45}
              className="text-green-400"
            />

            <h2 className="mt-6 text-2xl font-bold">
              AI Monitoring
            </h2>

            <p className="mt-2 text-slate-400">
              Live monitoring during every journey.
            </p>

          </div>

          {/* Profile */}

          <div className="rounded-3xl border border-slate-700 bg-slate-900 p-8">

            <User
              size={45}
              className="text-cyan-400"
            />

            <h2 className="mt-6 text-2xl font-bold">
              My Profile
            </h2>

          </div>

          {/* Contacts */}

          <div className="rounded-3xl border border-slate-700 bg-slate-900 p-8">

            <Phone
              size={45}
              className="text-cyan-400"
            />

            <h2 className="mt-6 text-2xl font-bold">
              Emergency Contacts
            </h2>

          </div>

        </div>

        <button
          className="mt-10 h-14 w-full rounded-2xl bg-red-500 text-lg font-semibold hover:bg-red-600"
        >
          Logout
        </button>

      </div>

    </main>
  );
}