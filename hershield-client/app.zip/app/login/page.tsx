"use client";

import Link from "next/link";
import { Eye, EyeOff, Lock, Mail } from "lucide-react";
import { useState } from "react";

import Background from "@/components/Background";
import AuthCard from "@/components/AuthCard";
import Logo from "@/components/Logo";

export default function LoginPage() {
  const [showPassword, setShowPassword] = useState(false);

  return (
    <Background>
      <AuthCard>

        <Logo />

        <h2 className="mb-8 text-center text-2xl font-bold text-white">
          Welcome Back
        </h2>

        {/* Email */}

        <div className="relative mb-5">

          <Mail
            className="absolute left-4 top-4 text-cyan-400"
            size={20}
          />

          <input
            type="email"
            placeholder="Email Address"
            className="h-14 w-full rounded-xl border border-slate-700 bg-slate-900/70 pl-12 text-white outline-none focus:border-cyan-500"
          />

        </div>

        {/* Password */}

        <div className="relative">

          <Lock
            className="absolute left-4 top-4 text-cyan-400"
            size={20}
          />

          <input
            type={showPassword ? "text" : "password"}
            placeholder="Password"
            className="h-14 w-full rounded-xl border border-slate-700 bg-slate-900/70 pl-12 pr-12 text-white outline-none focus:border-cyan-500"
          />

          <button
            type="button"
            className="absolute right-4 top-4 text-slate-400"
            onClick={() =>
              setShowPassword(!showPassword)
            }
          >
            {showPassword ? (
              <EyeOff size={20} />
            ) : (
              <Eye size={20} />
            )}
          </button>

        </div>

        <div className="mt-3 flex justify-end">

          <Link
            href="/forgot-password"
            className="text-sm text-cyan-400 hover:text-cyan-300"
          >
            Forgot Password?
          </Link>

        </div>

        <button
          className="mt-8 h-14 w-full rounded-xl bg-cyan-500 text-lg font-semibold transition hover:bg-cyan-600"
        >
          Login
        </button>

        <p className="mt-8 text-center text-slate-400">

          Don't have an account?

          <Link
            href="/signup"
            className="ml-2 font-semibold text-cyan-400 hover:text-cyan-300"
          >
            Create Account
          </Link>

        </p>

      </AuthCard>
    </Background>
  );
}