"use client";
import dynamic from "next/dynamic";
import { useEffect, useState } from "react";
import {
  MapPinned,
  Navigation,
  Route,
  ShieldCheck,
} from "lucide-react";
const Map = dynamic(
  () => import("@/components/Map"),
  {
    ssr: false,
  }
);

export default function JourneyPage() {
  const [source, setSource] = useState("");
  const [destination, setDestination] = useState("");
  const [latitude, setLatitude] = useState(0);
const [longitude, setLongitude] = useState(0);

useEffect(() => {
  navigator.geolocation.getCurrentPosition(
    (position) => {
      setLatitude(position.coords.latitude);
      setLongitude(position.coords.longitude);

      setSource(
        `${position.coords.latitude.toFixed(5)}, ${position.coords.longitude.toFixed(5)}`
      );
    },
    () => {
      alert("Please allow location access.");
    }
  );
}, []);

  return (
    <div className="min-h-screen bg-[#07111F] text-white">

      {/* Header */}

      <div className="border-b border-slate-800 bg-slate-900 px-8 py-6">

        <h1 className="text-3xl font-bold">
          Safe Journey
        </h1>

        <p className="mt-2 text-slate-400">
          AI Powered Safe Route Recommendation
        </p>

      </div>

      <div className="mx-auto mt-10 max-w-5xl px-6">

        <div className="grid gap-8 lg:grid-cols-2">

          {/* Left */}

          <div className="rounded-3xl bg-slate-900 p-8">

            <h2 className="mb-8 text-2xl font-bold">

              Journey Details

            </h2>

            {/* Source */}

            <div className="relative mb-6">

              <MapPinned
                className="absolute left-4 top-4 text-cyan-400"
              />

              <input
                value={source}
                onChange={(e) =>
                  setSource(e.target.value)
                }
                placeholder="Current Location"
                className="h-14 w-full rounded-xl border border-slate-700 bg-slate-800 pl-12 outline-none"
              />

            </div>

            {/* Destination */}

            <div className="relative">

              <Navigation
                className="absolute left-4 top-4 text-cyan-400"
              />

              <input
                value={destination}
                onChange={(e) =>
                  setDestination(
                    e.target.value
                  )
                }
                placeholder="Destination"
                className="h-14 w-full rounded-xl border border-slate-700 bg-slate-800 pl-12 outline-none"
              />

            </div>

            <button
              className="mt-8 h-14 w-full rounded-xl bg-cyan-500 text-lg font-semibold hover:bg-cyan-600"
            >
              Generate Safe Route
            </button>

          </div>

          {/* Right */}

          <div className="rounded-3xl bg-slate-900 p-8">

            <h2 className="mb-8 text-2xl font-bold">

              AI Route Summary

            </h2>

            <div className="space-y-6">

              <div className="rounded-xl bg-slate-800 p-5">

                <Route
                  className="mb-3 text-cyan-400"
                />

                <h3 className="font-semibold">

                  Distance

                </h3>

                <p className="text-slate-400">

                  12.5 km

                </p>

              </div>

              <div className="rounded-xl bg-slate-800 p-5">

                <Navigation
                  className="mb-3 text-cyan-400"
                />

                <h3 className="font-semibold">

                  Estimated Time

                </h3>

                <p className="text-slate-400">

                  22 Minutes

                </p>

              </div>

              <div className="rounded-xl bg-slate-800 p-5">

                <ShieldCheck
                  className="mb-3 text-green-400"
                />

                <h3 className="font-semibold">

                  Safety Score

                </h3>

                <p className="text-green-400 text-xl">

                  93%

                </p>

              </div>

            </div>

            <button
              className="mt-8 h-14 w-full rounded-xl bg-green-500 text-lg font-semibold hover:bg-green-600"
            >
              Start Journey
            </button>

          </div>

        </div>

        {/* Map */}

        <div className="mt-10 rounded-3xl bg-slate-900 p-6">

          <h2 className="mb-5 text-2xl font-bold">

            Live Map

          </h2>

         <Map />

        </div>

      </div>

    </div>
  );
}